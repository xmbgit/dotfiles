# nix-darwin Configuration Options {#book-darwin-manual}
## Version @DARWIN_VERSION@

```{=include=} options
id-prefix: opt-
list-id: configuration-variable-list
source: @DARWIN_OPTIONS_JSON@
```
